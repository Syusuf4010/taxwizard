import React from 'react';

function Success() {
  return <h1>Form Submitted Successfully!</h1>;
}

export default Success;
