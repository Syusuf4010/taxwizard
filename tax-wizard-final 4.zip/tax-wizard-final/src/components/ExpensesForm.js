import React from 'react';

function ExpensesForm({ data, setData }) {
  return (
    <div>
      <h2>Step 3: S-Corp Expenses</h2>
      <input
        type="number"
        placeholder="General Expenses"
        value={data.generalExpenses || ''}
        onChange={(e) => setData({ ...data, generalExpenses: e.target.value })}
      />
      <input
        type="number"
        placeholder="Owner Withdrawals"
        value={data.ownerWithdrawals || ''}
        onChange={(e) => setData({ ...data, ownerWithdrawals: e.target.value })}
      />
      <input
        type="number"
        placeholder="Extra Fund Distribution"
        value={data.extraDistribution || ''}
        onChange={(e) => setData({ ...data, extraDistribution: e.target.value })}
      />
    </div>
  );
}

export default ExpensesForm;
