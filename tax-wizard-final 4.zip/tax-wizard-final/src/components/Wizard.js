import React, { useState } from 'react';
import PersonalInfoForm from './PersonalInfoForm';
import IncomeForm from './IncomeForm';
import ExpensesForm from './ExpensesForm';
import ReasonableSalaryForm from './ReasonableSalaryForm';

function Wizard({ handleSubmit }) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({});

  const steps = [
    <PersonalInfoForm data={formData} setData={setFormData} />,
    <IncomeForm data={formData} setData={setFormData} />,
    <ExpensesForm data={formData} setData={setFormData} />,
    <ReasonableSalaryForm data={formData} setData={setFormData} handleSubmit={() => handleSubmit(formData)} />,
  ];

  return (
    <div>
      <div>
        {['Personal Info', 'Income', 'Expenses', 'Salary'].map((label, i) => (
          <button key={i} onClick={() => setStep(i + 1)} style={{ fontWeight: step === i + 1 ? 'bold' : 'normal' }}>
            Step {i + 1}: {label}
          </button>
        ))}
      </div>
      <div>{steps[step - 1]}</div>
    </div>
  );
}

export default Wizard;
