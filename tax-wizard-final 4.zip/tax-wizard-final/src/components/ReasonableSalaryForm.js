import React from 'react';

function ReasonableSalaryForm({ data, setData, handleSubmit }) {
  return (
    <div>
      <h2>Step 4: Reasonable Salary</h2>
      <input
        type="number"
        placeholder="Reasonable Salary"
        value={data.reasonableSalary || ''}
        onChange={(e) => setData({ ...data, reasonableSalary: e.target.value })}
      />
      <p>
        A “reasonable salary” is the compensation that an owner actively working
        in the S-Corp would be paid for similar work at another company. The IRS
        expects you to pay yourself this before taking distributions.
      </p>
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
}

export default ReasonableSalaryForm;
