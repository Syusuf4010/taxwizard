import React from 'react';

function IncomeForm({ data, setData }) {
  return (
    <div>
      <h2>Step 2: Income Information</h2>
      <input
        type="number"
        placeholder="Personal Income"
        value={data.personalIncome || ''}
        onChange={(e) => setData({ ...data, personalIncome: e.target.value })}
      />
      <input
        type="number"
        placeholder="S-Corp Income"
        value={data.sCorpIncome || ''}
        onChange={(e) => setData({ ...data, sCorpIncome: e.target.value })}
      />
    </div>
  );
}

export default IncomeForm;
