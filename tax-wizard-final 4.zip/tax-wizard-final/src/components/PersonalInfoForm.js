import React from 'react';

function PersonalInfoForm({ data, setData }) {
  return (
    <div>
      <h2>Step 1: Personal Information</h2>
      <input
        type="text"
        placeholder="Full Name"
        value={data.name || ''}
        onChange={(e) => setData({ ...data, name: e.target.value })}
      />
      <input
        type="email"
        placeholder="Email"
        value={data.email || ''}
        onChange={(e) => setData({ ...data, email: e.target.value })}
      />
    </div>
  );
}

export default PersonalInfoForm;
