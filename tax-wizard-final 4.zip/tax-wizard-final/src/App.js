import React from 'react';
import Wizard from './components/Wizard';

function App() {
  const handleSubmit = async (data) => {
    const res = await fetch("https://api.web3forms.com/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        access_key: "987654fb-2ba8-4c50-91ff-21c28961411b", // replace with your actual key
        ...data,
      }),
    });

    if (res.ok) {
      window.location.href = "/success";
    } else {
      alert("Submission failed");
    }
  };

  return <Wizard handleSubmit={handleSubmit} />;
}

export default App;
